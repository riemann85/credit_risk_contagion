'''
This module contains functions to analyze results of clustering with approach based on time windows.
They are used in the notebook 04.3_Analysis_Results_Clustering_Time_Windows.
'''

import numpy as np
from matplotlib import pyplot as plt
from matplotlib import colors as cls
from ts_correlation import *

def top_rf_per_curve(df_values, curve, rf_list, tw, k):
    '''
    This function computes closest risk factors to an issuer curve in a time window, where proximity is based on correlation-based distance.
    
    Arguments:
        df_values: df with shape (total_n_series, window_shape+2), where total_n_series is the number of issuer curves
                    plus the number of risk factors multiplied by the number of time windows, while the 2 extra columns 
                    are curveId and time window bounds as string
        curve: string with curveId of the issuer curve
        rf_list: list of risk factors in df_values
        tw: wime window identifier as string with bounds (e.g., '21/05/2015-23/09/2015')
        k: number of desired top rf
        
    Returns:
        top_rf_list: list of top k risk factors for the input issuer curve
        
    '''
    
    window_values_curr_cl_rf_tw = df_values.\
        loc[lambda x: ((x['curveId'] == curve) | (x['curveId'].isin(rf_list))) & (x['time_window'] == tw)].\
        set_index('curveId', drop=True).drop(columns=['time_window'])
    df_correlation = compute_ts_correlation(window_values_curr_cl_rf_tw.T,
                                           res_index=rf_list, res_columns=[curve],
                                           return_distance=True)
    top_rf_list = list(df_correlation.sort_values(by=curve).head(k).index)
    
    return top_rf_list

def top_rf_per_cl(df_values, tw, k, rf_list, issuer_list, df_clust_res_issuer):
    '''
    This function computes a measure of proximity of risk factors to the issuer clusters in a specified time window.
    In particular, it first computes the closest k risk factors to each issuer curve in terms of correlation-based
    distance. After that, per each issuer cluster, the percentage of issuer curves in the cluster for which each
    risk factor appears in the top k is computed and returned.
    
    Arguments:
        df_values: df with shape (total_n_series, window_shape+2), where total_n_series is the number of issuer curves
                    plus the number of risk factors multiplied by the number of time windows, while the 2 extra columns 
                    are curveId and time window bounds as string
        tw: wime window identifier as string with bounds (e.g., '21/05/2015-23/09/2015')
        k: number of desired top rf
        rf_list: list of risk factors in df_values
        issuer_list: list of issuer in df_values
        df_clust_res_issuer: df with shape (n_issuer_curves, n_windows+1) with clustering results. 
                             The extra column contains the curveId
        
    Returns:
        df_top_rf_per_cl: df with shape (n_issuer_clusters, n_risk_factors), specifying the percentage of curves each risk
                          factor is in the closest k to the curves in the cluster
    '''

    window_values_curr_cl_rf_tw = df_values.\
        loc[lambda x: x['time_window'] == tw].\
        set_index('curveId', drop=True).drop(columns=['time_window'])
    df_correlation = compute_ts_correlation(window_values_curr_cl_rf_tw.T,
                                            res_index=rf_list,
                                            res_columns=issuer_list,
                                            return_distance=True)
    df_top_rf_per_curve = df_correlation.T.assign(threshold=np.sort(df_correlation.T.to_numpy())[:, k-1])
    for i in range(len(df_top_rf_per_curve)):
        df_top_rf_per_curve.iloc[i, 0:((df_top_rf_per_curve.shape[1]-1))] = \
            np.where(df_top_rf_per_curve.iloc[i, 0:((df_top_rf_per_curve.shape[1]-1))] <= df_top_rf_per_curve.iloc[i, df_top_rf_per_curve.shape[1]-1], 1, 0)

    df_top_rf_per_curve.drop(columns=['threshold'], inplace=True)
    df_top_rf_per_curve = df_top_rf_per_curve.\
        merge(df_clust_res_issuer.set_index('curveId').loc[:, tw], left_index=True, right_index=True).\
        rename(columns={tw: 'cluster_label'})
    df_top_rf_per_cl = df_top_rf_per_curve.groupby('cluster_label').apply(lambda x: x.sum()/len(x)).\
        drop(columns='cluster_label')
    
    return df_top_rf_per_cl


def plot_issuer_and_top_rf_in_issuer_cluster(df_values, df_clust_res_issuer, df_clust_res_rf, tw, cl, 
                                               rf_input_list, issuer_input_list, k):
    '''
    This function plots time series in a specified input cluster and closest risk factors to the cluster in terms
    of correlation-based distance. Another option is plotting a specified issuer curve instead of a cluster
    of issuer curves.
    
    Arguments:
        df_values: df with shape (total_n_series, window_shape+2), where total_n_series is the number of issuer curves
                    plus the number of risk factors multiplied by the number of time windows, while the 2 extra columns 
                    are curveId and time window bounds as string
        df_clust_res_issuer: df with shape (n_issuer_curves, n_windows+1) with clustering results. 
                             The extra column contains the curveId
        df_clust_res_rf: df with shape (n_risk_factors, n_windows+1) with clustering results. 
                         The extra column contains the curveId
        tw: wime window identifier as string with bounds (e.g., '21/05/2015-23/09/2015')
        cl: if `int`, it is a cluster label; if `string`, it is a curveId
        rf_input_list: list of risk factors in df_values
        issuer_input_list: list of issuer in df_values
        k: number of desired top rf 
        
    '''
    
    if type(cl) == int:
        df_top_rf = top_rf_per_cl(df_values, tw, k, rf_input_list, issuer_input_list)

        rf_list = list(df_top_rf.T.sort_values(by=cl, ascending=False).loc[lambda x: x[cl] >= 0.8].index)
        issuer_list = list(df_clust_res_issuer.loc[lambda x: x[tw] == cl]['curveId'])
    else:
        rf_list = top_rf_per_curve(df_values, cl, rf_input_list, tw, k)
        issuer_list = [cl]
        
    df_curr_tw = df_values.loc[lambda x: x['time_window'] == tw]
        
    fig = plt.figure()
    ax = fig.add_subplot(2,1,1)
    for curve in issuer_list:
        xx = df_curr_tw.loc[lambda x: x['curveId'] == curve].drop(columns=['curveId', 'time_window']).values
        ax.plot(xx.ravel())

    ax = fig.add_subplot(2,1,2)
    rf_list_legend = []
    for rf in rf_list:
        xx = df_curr_tw.loc[lambda x: x['curveId'] == rf].drop(columns=['curveId', 'time_window']).values
        cluster = df_clust_res_rf.loc[lambda x: x['curveId'] == rf, tw].values[0]
        rf_list_legend.append(rf + str(' - cluster ') + str(cluster))
        ax.plot(xx.ravel())
    ax.legend(rf_list_legend)


    fig.set_size_inches(18,10)
    
    
def plot_series_tw_clustering(df_observations, time_windows, len_time_windows, clustering_results,
                              colors, cluster_patterns, output_path=None):
    '''
    This function plots time series and highlights the results of clustering with time windows.
    In particular, the colour of the series in each time window depends on the cluster where the curves
    belong in that time time window.
    
    Arguments:
        df_observations: df with shape (n_timestamps, n_curves) with values of time series, with date as index
        time_windows: dictionary with 0,...,n_time_window-1 as key and a 2-elements list as value, with the start
                      and end day of the corresponding time window
        len_time_windows: number of days in each time window
        clustering_results: df with shape (n_curves, n_windows+1) with clustering results. 
                            The extra column contains the curveId
        colors: matplotlib.colors.ListedColormap object with colors per each cluster
        cluster_patterns: dictionary with a string label per each cluster label
        output_path: path to the folder where the .png with the charts must be saved. Each plot will be saved as .png
                     file with the curveId as name. Default=None, images are not saved
        
    '''
    
    # Compute number of timestamps as number of time windows multiplied by length of the time window
    num_time_windows = len(time_windows)
    total_len_series_tw = num_time_windows * len_time_windows

    # Remove the last points of the time series, since they were disregarded in the window approach
    df_observations_cut = df_observations.iloc[:total_len_series_tw, :]
    
    for curve in df_observations_cut.columns:

        cluster_labels = np.array(clustering_results.set_index('curveId').loc[curve,:])

        curr_clust_patt = [cluster_patterns[i] for i in list(set(cluster_labels))]

        bounds_time_windows = [*[time_windows[i][0] for i in time_windows], *[time_windows[len(time_windows)-1][1]]]

        plt.figure(figsize=(16,8))

        plt.plot(df_observations_cut.loc[:, curve], c='black', alpha=0.3)
        scatter = plt.scatter(df_observations_cut.index, df_observations_cut.loc[:, curve], 
                              c=[label for label in cluster_labels for i in range(len_time_windows)],
                              cmap=colors,
                              norm=cls.Normalize(vmin=min(cluster_patterns.keys()), vmax=max(cluster_patterns.keys())))
        plt.xticks(bounds_time_windows, rotation=90)
        plt.grid(axis='x')

        plt.legend(handles=scatter.legend_elements()[0], labels=curr_clust_patt, title='Cluster', fontsize='large')
        plt.title(curve, fontsize='x-large')

        np.set_printoptions(False)
        
        if output_path is not None:
            plt.savefig(output_path + curve + '.png', facecolor='white')  
    
  