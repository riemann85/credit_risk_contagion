'''
This module contains utilities for computation of correlation measures between time series
'''

import pandas as pd
import numpy as np
from scipy.spatial.distance import cdist
from matplotlib import pyplot as plt
import seaborn

def compute_ts_correlation(df, detrend_strategy='diff', res_index=None, res_columns=None, return_distance=False):
    '''
    This function computes correlation between time series in a dataframe.
    
    Arguments:
        df: input dataframe with shape (n_timestamp, n_series)
        detrend_strategy: strategy to remove trend from series, current options are 'diff' for first-order differences, 'perc_change' for percentage change and None for no detrend. Default = 'diff'
        res_index: list of time series from df to appear in the index of the resulting df. Default = None, take all series from df
        res_columns: list of time series from df to appear in the columns of the resulting df. Default = None, take all series from df
        return_distance: if True, correlation-based distance is computed. Otherwise, linear correlation is computed. Default=False
     
     Returns:
         df with shape (len(res_index), len(res_columns)) with correlation between time series
    '''
    
    if res_index is None:
        res_index = df.columns
        
    if res_columns is None:
        res_columns = df.columns
    
    if detrend_strategy == 'perc_change':
        df_changed = df.pct_change()
    elif detrend_strategy == 'diff':
        df_changed = df.diff()
    else:
        df_changed = df
        
    if not return_distance:
        df_correlations = df_changed.corr().loc[res_index, res_columns]
    else:
        mat_1 = df.loc[:, res_index].T
        mat_2 = df.loc[:, res_columns].T
        df_correlations = pd.DataFrame(cdist(mat_1, mat_2, metric='correlation'), index=res_index, columns=res_columns)

    
    return df_correlations


def find_top_k_rf_correlation_by_time_window(df_clustering, df_series, time_windows, k,
                                             rf_list, link_metric):
    '''
    This function returns top k risk factors per cluster and time window, according to the
    link metric between issuer curves and risk factors specified in input.
    
    Arguments:
        df_clustering: df with clustering results with shape (n_curves, n_time_windows)
        df_series: df with all series data (including also risk factors) with shape (n_timestamp, n_series)
        time_windows: dictionary with 0, ..., num_windows-1 as keys and beginning-end days of each time window as value
        k: number of top risk factors to return per each cluster-time_window
        rf_list: list of risk factors to take into account
        link_metric: metric to link curves and risk factors ('corr', 'corr_based_dist', 'varInfo')
        
    Returns:
        top_factors_per_tw: dictionary with time window identifiers as keys and a dictionary as value.
                            Each value is a dictionary with information on top risk factors in each cluster,
                            as returned from the function 'top_k_rf_per_cluster'
    '''
    
    top_factors_per_tw = {}
    
    for tw in time_windows:
        
        series_curr_tw = df_series.loc[(df_series.index >= time_windows[tw][0]) & (df_series.index <= time_windows[tw][1]), :]
        
        if link_metric in ['corr', 'corr_based_dist']:
            df_corr_curr_tw = compute_ts_correlation(series_curr_tw,
                                                   detrend_strategy='diff',
                                                   res_index=list(df_clustering.index),
                                                   res_columns=rf_list,
                                                   return_distance=(link_metric=='corr_based_dist'))
        else:
            df_corr_curr_tw = varInfoDf(series_curr_tw, detrend_strategy='diff', norm=True,
                                       res_index=list(df_clustering.index),
                                       res_columns=rf_list)
        
        df_corr_curr_tw['cluster_label'] = list(df_clustering.iloc[:, tw])
        top_factors_per_cluster = top_k_rf_per_cluster(df_corr_curr_tw, link_metric, k)
        
        top_factors_per_tw[tw] = top_factors_per_cluster
        
    
    return top_factors_per_tw
        
        
        
def top_k_rf_per_cluster(df_results, link_metrics, k):
    '''
    This function identifies most important risk factors in each cluster. Most important risk factors
    are identified based on the average value of the link metric with curves in each cluster.
    
    Arguments:
        df_results: df with shape (n_curves, n_risk_factors+1), containing link metric for each pair curve-risk_factor.
                    In addition, last column contains cluster label
        link_metrics: link metric between curves and risk factors ('corr', 'corr_based_dist', 'varInfo')
        k: number of top risk factors to include per each cluster
        
    Returns:
        top_factors_per_cluster: dictionary with cluster label as key and a dictionary as value.
                                 Each value has a field 'factors' with the list of risk factors
                                 and a field 'avg_corr' with the average value of the link metric
    '''
    
    
    top_factors_per_cluster = {}
    
    if link_metrics == 'corr':

        for cl in df_results['cluster_label'].unique():

            res_current_cl = df_results[df_results['cluster_label'] == cl]
            res_current_cl_abs_corr = abs(res_current_cl).drop(columns='cluster_label')
            avg_abs_corr_factors = {}
            avg_corr_factors = {}

            for factor in res_current_cl_abs_corr.columns:
                avg_abs_corr_factors[factor] = np.average(res_current_cl_abs_corr.loc[:, factor])
                avg_corr_factors[factor] = np.average(res_current_cl.loc[:, factor])

            top_factors_per_cluster[cl] = {}
            top_factors_per_cluster[cl]['factors'] = list(pd.DataFrame(avg_abs_corr_factors.items(), columns=['rf', 'avg_corr']).\
                                            sort_values(by='avg_corr', ascending=False).\
                                            head(k)[['rf']].sort_values(by='rf')['rf'])
            top_factors_per_cluster[cl]['avg_corr'] = list(pd.DataFrame(avg_corr_factors.items(), columns=['rf', 'avg_corr']).\
                                            loc[lambda x: x['rf'].isin(top_factors_per_cluster[cl]['factors'])].\
                                            sort_values(by='rf')['avg_corr'])
        
    else:

        for cl in df_results['cluster_label'].unique():

            res_current_cl = df_results[df_results['cluster_label'] == cl].drop(columns='cluster_label')
            avg_corr_factors = {}

            for factor in res_current_cl.columns:
                avg_corr_factors[factor] = np.average(res_current_cl.loc[:, factor])

            top_factors_per_cluster[cl] = {}
            top_factors_per_cluster[cl]['factors'] = list(pd.DataFrame(avg_corr_factors.items(), columns=['rf', 'avg_corr']).\
                                            sort_values(by='avg_corr', ascending=True).\
                                            head(k)[['rf']].sort_values(by='rf')['rf'])
            top_factors_per_cluster[cl]['avg_corr'] = list(pd.DataFrame(avg_corr_factors.items(), columns=['rf', 'avg_corr']).\
                                            loc[lambda x: x['rf'].isin(top_factors_per_cluster[cl]['factors'])].\
                                            sort_values(by='rf')['avg_corr'])
        
        
    return top_factors_per_cluster    
        
    
    
    
def remove_correlated_risk_factors(df, list_rf, corr_threshold, detrend_strategy='diff', rf_to_keep=[]):
    '''
    This function removes identifies most correlated risk factors and removes them from the analysis,
    leaving only risk factors that have a pairwise correlation lower than a specified threshold.
    The function also shows a heatmap of correlations between risk factors with value higher than the threshold.

    Arguments:
        df: df with shape (n_timestamps, n_series); it must contain series of all risk factors, but can also have other series
        list_rf: list of risk factors to be included in the analysis
        corr_threshold: threshold for correlation; if two risk factors have a higher correlation, one of them is removed
        detrend_strategy: strategy to remove trend from series, current options are 'diff' for first-order differences, 'perc_change' for percentage change and None for no detrend. Default = 'diff'
        rf_to_keep: list of risk factors to keep in the analysis, these will not be removed

    Returns:
        rf_to_remove: list of risk factors to be removed
    '''
    
    df_correlation_rf = compute_ts_correlation(df,
                                              detrend_strategy=detrend_strategy,
                                              res_index=list_rf,
                                              res_columns=list_rf)
    
    fig, ax = plt.subplots(1, 1, figsize=(13, 8))
    seaborn.heatmap(df_correlation_rf[abs(df_correlation_rf)>=corr_threshold], annot=True)

    a, b = np.where(abs(df_correlation_rf.values) >= corr_threshold)
    rf_high_corr = {}
    for i in range(len(a)):
        rf1 = df_correlation_rf.columns[a[i]]
        rf2 = df_correlation_rf.columns[b[i]]
        if rf1 != rf2:
            if rf1 not in rf_high_corr:
                rf_high_corr[rf1] = [rf2]
            else:
                rf_high_corr[rf1].append(rf2)

    rf_high_corr = dict(sorted(rf_high_corr.items()))

    rf_to_remove = []
    for rf in rf_high_corr:
        if rf not in rf_to_remove:
            rf_to_remove = [*rf_to_remove, *[i for i in rf_high_corr[rf] if i not in rf_to_keep]]


    return rf_to_remove
        
        
    
    
    
    
    
    














