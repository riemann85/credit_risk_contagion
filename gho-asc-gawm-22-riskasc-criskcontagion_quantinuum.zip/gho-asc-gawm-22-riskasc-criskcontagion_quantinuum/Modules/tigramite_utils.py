'''
This module contains utilities based on the library tigramite to compute partial correlation in time series datasets via conditional independence tests.
'''

import sys
sys.path.append('../Modules')
from read_prepare_input_clustering import *
from preprocess_series import *
from tslearn.preprocessing import TimeSeriesScalerMinMax, TimeSeriesScalerMeanVariance
import time
from tigramite import data_processing as pp
from tigramite.pcmci import PCMCI
from tigramite.independence_tests import ParCorr



def compute_partial_correlation_tigramite(df_sector, df_periods=None, status=None, model_graph=None, max_lag=30):
    '''
    Given a directed graph representing links between time series, this function computes partial auto-correlation of all time series and partial cross-correlation between series linked by edges.
    
    Arguments:
        df_sector: df with shape (n_timesteps, n_series) containing time series data for all nodes of the graph, having dates as index
        df_periods: df with columns status, min_date, max_date to specify min and max date of each period identified by the column status. Default=None, meaning that the whole df_sector must be used
        status: name of the period (columns status in df_periods) in which the correlations must be computed. Default=None, meaning that the whole time horizon is taken into account
        model_graph: networkx.classes.digraph.DiGraph object that specifies the directed graph structure between the time series
        max_lag: maximum lag at which correlations must be computed
            
    Returns:
        new_significant_arcs: df with columns from, to, value specifying the value of the most significant partial cross-correlation in each edge
        dict_edge_labels: dictionary having a tuple representing the edge as key and the value of the lag with the most significant partial cross-correlation between the two time series connected by the edge
        node_colors: list with the values of the most significant absolute partial auto-correlation of each time series. The order of the nodes is that obtained by calling list(model_graph.nodes)
        
    '''

    # Select only records in a specified period (status)
    if df_periods is not None:
        min_date = df_periods[df_periods['status'] == status]['min_date'].values[0]
        max_date = df_periods[df_periods['status'] == status]['max_date'].values[0]
    else:
        min_date = min(df_sector.index)
        max_date = max(df_sector.index)
    df_sector_curr_status = df_sector.loc[(df_sector.index >= min_date) & (df_sector.index <= max_date)]

    np.random.seed(0)

    # Initialize dataframe object, specify time axis and variable names
    var_names = [i.split('-')[0] for i in df_sector_curr_status.columns]
    df_sector_curr_status.columns = var_names
    var_names = list(model_graph.nodes())

    dataframe = pp.DataFrame(df_sector_curr_status[list(model_graph.nodes())].values, 
                             datatime = np.arange(len(df_sector_curr_status)), 
                             var_names=var_names)

    # Define PCMCI model
    parcorr = ParCorr(significance='analytic')
    pcmci = PCMCI(
        dataframe=dataframe, 
        cond_ind_test=parcorr,
        verbosity=0)

    # Fit PCMCI model
    results = pcmci.run_pcmci(tau_max=max_lag, pc_alpha=None, alpha_level=0.001)

    ## Add columns "value" to "significant arcs" to specify the value of the partial correlation
    ## Define also dictionary with labels per each edge: used to add lag value to the edge
    array_var_names = np.array(var_names)
    new_significant_arcs = pd.DataFrame(list(model_graph.edges()), columns=['from', 'to']).assign(value=0)
    dict_edge_labels = {}            
    for edge in list(model_graph.edges()):
        source_node = edge[0]
        sink_node = edge[1]

        id_source = np.where(array_var_names == source_node)[0][0]
        id_sink = np.where(array_var_names == sink_node)[0][0]

        sorted_p_values = np.argsort(results['p_matrix'][id_source, id_sink, :])
        if sorted_p_values[0] != 0:
            id_most_significant = sorted_p_values[0]
        else:
            id_most_significant = sorted_p_values[1]
        par_corr_value = results['val_matrix'][id_source, id_sink, id_most_significant]

        new_significant_arcs.loc[lambda x: (x['from'] == source_node) & (x['to'] == sink_node), 'value'] = par_corr_value
        dict_edge_labels[(source_node, sink_node)] = id_most_significant



    ## Define a list with the most significant auto-correlation per each node in order to color nodes in the graph
    node_colors = []
    for node in list(model_graph.nodes):
        id_node = np.where(np.array(var_names) == node)[0][0]
        id_most_significant = np.argsort(results['p_matrix'][id_node, id_node, :])[0]
        auto_corr_value = abs(results['val_matrix'][id_node, id_node, id_most_significant])
        node_colors.append(auto_corr_value)
        
    return new_significant_arcs, dict_edge_labels, node_colors