'''
This module contains utilities to compute mutual information and variation of information metrics.
See https://github.com/emoen/Machine-Learning-for-Asset-Managers/blob/master/Machine_Learning_for_Asset_Managers/ch3_metrics.py for details.
'''

import numpy as np
import pandas as pd
import scipy.stats as ss
from sklearn.metrics import mutual_info_score


def numBins(nObs, corr=None):
    #optimal number of bins for discretization
    if corr is None: #univariate case
        z = (8+324*nObs+12*(36*nObs+729*nObs**2)**.5)**(1/3.)
        b = round(z/6.+2./(3*z)+1./3)
    else: #bivariate case
        b = round(2**-.5*(1+(1+24*nObs/(1.-corr**2))**.5)**.5)
    
    return int(b)

# +

def varInfo(x,y, norm=False):
    #variation of information
    bXY = numBins(x.shape[0], corr= np.corrcoef(x,y)[0,1])
    bins = bXY
    cXY = np.histogram2d(x, y, bins)[0]
    hX = ss.entropy(np.histogram(x, bins)[0]) #marginal 
    hY = ss.entropy(np.histogram(y, bins)[0]) #marginal
    iXY = mutual_info_score(None, None, contingency=cXY)
    vXY = hX+hY-2*iXY #variation of information
    if norm:
        hXY = hX + hY - iXY #joint
        vXY = vXY/hXY #normalized variation of information - Kraskov (2008)
        
    return vXY


# -

#codesnippet 3.4 Correlation and normalized mutual information of two independent gaussian random variables
def mutualInfor(x,y, norm=False):
    #mutual information
    bXY = numBins(x.shape[0], corr = np.corrcoef(x,y)[0,1])
    cXY = np.histogram2d(x,y, bXY)[0]
    iXY = mutual_info_score(None, None, contingency=cXY)
    if norm:
        hX = ss.entropy(np.histogram(x, bXY)[0]) #marginal 
        hY = ss.entropy(np.histogram(y, bXY)[0]) #marginal
        iXY /= min(hX, hY) #normalized mutual information

    return iXY




def varInfoDf(df, detrend_strategy=None, norm=False, res_index=None, res_columns=None):
    '''
    This function computes variation of information between series in the input df.
    
    Arguments:
        df: input dataframe with shape (n_timestamp, n_series)
        detrend_strategy: strategy to remove trend from series, current options are 'diff' for first-order differences, 'perc_change' for percentage change and None for no detrend. Default = 'diff'
        norm: whether to normalize variation of information or not
        res_index: list of columns from df to appear in the index of the resulting df. Default = None, take all columns from df
        res_columns: list of columns from df to appear in the columns of the resulting df. Default = None, take all columns from df
        
    Returns:
        df with shape (len(res_index), len(res_columns)) with variation of information between time series
    '''
    
    
    if res_index is None:
        res_index = df.columns
        
    if res_columns is None:
        res_columns = df.columns
        
    if detrend_strategy == 'perc_change':
        df_changed = df.pct_change()
    elif detrend_strategy == 'diff':
        df_changed = df.diff()
    else:
        df_changed = df
    
    num_series = df.shape[1]
    res_matrix = np.zeros((len(res_index), len(res_columns)))
    
    for i in range(len(res_index)):
        for j in range(len(res_columns)):
            
            if res_index[i] != res_columns[j]:
                
                x = np.array(df.loc[:, res_index[i]])
                y = np.array(df.loc[:, res_columns[j]])

                res_matrix[i][j] = varInfo(x, y, norm=norm)
                
    res_df = pd.DataFrame(res_matrix, index=res_index, columns=res_columns)
        
    return res_df

