'''
This module contains utilities for the preprocessing of time series data.
'''

import pandas as pd
import random
from sklearn.decomposition import PCA
import numpy as np
from tslearn.barycenters import euclidean_barycenter, dtw_barycenter_averaging

def preprocess_data(df, df_all_sectors, parameters):
    '''
    This function performs some preprocessing on the input time series data.
    
    Arguments:
        df: input df with time series data, with shape (n_dim, n_samples).
        df_all_sectors = df with all pairs curve_id - sector (used for barycenter computation and removal)
        parameters: dictionary with following parameters for preprocessing:
            use_differences: use first order differences (True) or raw data (False)
            scaling_strategy: class to be used for scaling time series (e.g., TimeSeriesScalerMeanVariance())
            subtract_sector_barycenter: subtract barycenter computed per sector (True) or not (False)
            sector_barycenter_metric: metric to be used for sector-barycenter computation
            dim_reduction: apply dimensionality reduction to time series (True) or not (False)
            dim_reduction_alg: class to be used for dimensionality reduction (e.g., PCA)
            dim_reduction_num_components: number of target dimension for dimensionality reduction (for PCA, it can also be fraction of desired explained variance)
            dim_red_rnd_state: random state for dimensionality reduction (useful for reproducibility for PCA)
            
    Returns:
        df with shape (n_dim, n_samples) resulting from preprocessing
    '''

    use_differences = parameters['use_differences']
    scaling_strategy = parameters['scaling_strategy']
    subtract_sector_barycenter = parameters['subtract_sector_barycenter']
    sector_barycenter_metric = parameters['sector_barycenter_metric']
    dim_reduction = parameters['dim_reduction']
    dim_reduction_alg = parameters['dim_reduction_alg']
    dim_reduction_num_components = parameters['dim_reduction_num_components']
    dim_red_rnd_state = parameters['dim_red_rnd_state']



    # Compute differences between two consecutive days and fill NA values
    # Remove also first day, since you can compute no difference for it
    if use_differences:
        df_all_lookup_diff = df.diff().fillna(method='bfill', axis=0).fillna(method='ffill', axis=0)
        df_all_lookup_diff = df_all_lookup_diff.iloc[1:len(df_all_lookup_diff), :]
    else:
        df_all_lookup_diff = df.fillna(method='bfill', axis=0).fillna(method='ffill', axis=0)    
        
    # Subtract barycenter of time series: barycenter is computed per each sector
    df_decenter = pd.DataFrame()
    if subtract_sector_barycenter:
        for sector in df_all_sectors['MS_Sector'].unique():
            cids = df_all_sectors.loc[df_all_sectors['MS_Sector']==sector,'CurveID'].unique()
            df_all_lookup_complete_sector = df_all_lookup_diff.loc[:,df_all_lookup_diff.columns.isin(cids)]
            X = df_all_lookup_complete_sector.values
            if sector_barycenter_metric == 'dtw':
                barycenter = dtw_barycenter_averaging(X.T, max_iter=50, tol=1e-3)
            elif sector_barycenter_metric == 'euclidean':
                barycenter = euclidean_barycenter(X.T)
            df_decenter_sector = (df_all_lookup_diff.loc[:,df_all_lookup_diff.columns.isin(cids)] - barycenter)
            df_decenter = pd.concat([df_decenter, df_decenter_sector], axis=1)
    else:
        df_decenter = df_all_lookup_diff
        
    # Scale data
    if scaling_strategy is not None:
        df_all_lookup_scaled = pd.DataFrame(scaling_strategy.fit_transform(df_decenter.T).\
            reshape(df_decenter.T.shape[0], df_decenter.T.shape[1])).T
        df_all_lookup_scaled.columns = df_decenter.columns
    else:
        df_all_lookup_scaled = df_decenter
        
    # Apply dimensionality reduction via PCA
    if dim_reduction:
        X = df_all_lookup_scaled.values.T
        if dim_reduction_alg == PCA:
            dim_red_alg = dim_reduction_alg(dim_reduction_num_components, random_state=dim_red_rnd_state)
        else:
            dim_red_alg = dim_reduction_alg(dim_reduction_num_components)
        dim_red_alg.fit(X)
        X_reduced = dim_red_alg.fit_transform(X)
        X_reduced = X_reduced.reshape(X_reduced.shape[0], X_reduced.shape[1])
        if dim_reduction_alg == PCA:
            print('Percentage variance explained: ' + str(np.cumsum(dim_red_alg.explained_variance_ratio_)))
        df_all_lookup_scaled = pd.DataFrame(X_reduced.T, columns=df_all_lookup_scaled.columns)
        
        
    return df_all_lookup_scaled


