'''
This module includes functions to read and prepare input data needed for clustering of issuer curves based on their links with risk factors.
'''

import pandas as pd

def import_data_clustering_issuer_rf(issuer_curves_file_name='Sprd_5Y_Gesav_import_Sector_values.csv',
                                    sep_issuer_curves_file=',',
                                    fx_rf_file_name='Observations - UniverseFX.csv',
                                    local_rf_file_name='Observations - UniverseLOCAL.csv',
                                    sep_rf_file=',',
                                    local_rf_to_include=None,
                                    fx_rf_to_include=None,
                                    all_rf_to_include=None):
    '''
    This function reads all input data needed for clustering of issuer curves based on links with risk factors.
    
    Arguments:
        issuer_curves_file_name: name of the .csv file with spread of issuer curves
        sep_issuer_curves_file: separator used in the file with spread data
        fx_rf_file_name: name of the .csv file with values of the foreign exchange risk factors
        local_rf_file_name: name of the .csv file with values of the local risk factors
        sep_rf_file: separator used in the files with info about risk factors
        local_rf_to_include: name of the .csv file with the list of local risk factors to include in the analysis (the file must contain only one column)
        fx_rf_to_include: name of the .csv file with the list of fx risk factors to include in the analysis (the file must contain only one column)
        all_rf_to_include: name of the .csv file with the list of all risk factors to include in the analysis (the file must contain only one column)
        
    Returns:
        df_all: df with issuer curves spread values
        df_all_lookup:: df_all after pivot operations to have dates as index and issuer names as columns
        obs_universe_fx: df with info about fx risk factors, with dates as index and risk factors names as columns
        obs_universe_local: df with info about local risk factors, with dates as index and risk factors names as columns
        risk_factors_to_include: list of risk factors to include in the analysis
        
    '''
    
    
    # Read input dataset
    try:
        df_all = pd.read_csv('../Data/' + issuer_curves_file_name, sep = sep_issuer_curves_file)
    except:
        df_all = pd.read_csv(issuer_curves_file_name, sep=sep_issuer_curves_file)
        
    # Pivot input dataset
    df_all['Date'] = pd.to_datetime(df_all['Date'])
    df_all.head()

    df_all_lookup = df_all.pivot_table( index='Date',columns = "CurveID", values ="Sprd").iloc[:,:].sort_index(ascending=True,inplace=False)
    df_all_lookup.head()
    
    # Read files about risk factors
    try:
        obs_universe_fx = pd.read_csv('../Data/' + fx_rf_file_name, sep=sep_rf_file, thousands=',')
        obs_universe_local = pd.read_csv('../Data/' + local_rf_file_name, sep=sep_rf_file, thousands=',')
    except:
        obs_universe_fx = pd.read_csv(fx_rf_file_name, sep=sep_rf_file, thousands=',')
        obs_universe_local = pd.read_csv(local_rf_file_name, sep=sep_rf_file, thousands=',')

    
    obs_universe_fx['Date[Date]'] = pd.to_datetime(obs_universe_fx['Date[Date]'])
    obs_universe_local['Date[Date]'] = pd.to_datetime(obs_universe_local['Date[Date]'])

    obs_universe_fx = obs_universe_fx.set_index('Date[Date]', drop=True).drop(columns='level')
    obs_universe_local = obs_universe_local.set_index('Date[Date]', drop=True).drop(columns='level')

    if all_rf_to_include is None:
        if local_rf_to_include is None:
            local_risk_factors_to_include = []
        else:
            local_risk_factors_to_include = list(pd.read_csv('../Data/' + local_rf_to_include).iloc[:, 0])
            
        if fx_rf_to_include is None:
            fx_risk_factors_to_include = []
        else:
            fx_risk_factors_to_include = list(pd.read_csv('../Data/' + fx_rf_to_include).iloc[:, 0])
            
        risk_factors_to_include = [*local_risk_factors_to_include, *fx_risk_factors_to_include]
    
    else:
        risk_factors_to_include = list(pd.read_csv('../Data/' + all_rf_to_include).iloc[:, 0])
    
    
    return df_all, df_all_lookup, obs_universe_fx, obs_universe_local, risk_factors_to_include





def remove_series_mostly_na(df, min_percentage):
    '''
    This function removes from the input df all series having more than an input percentage of NA values.
    
    Arguments:
        df: input dataframe with dates as index and time series names as columns
        min_percentage: minimum percentage of non NA values to keep a series in the dataframe
        
    Returns:
        df_return: input df without the series not having at least min_percentage non NA observations
    '''
    
    l = []
    for c in df.columns:
        idx_max = df.loc[df[c].notna() == True].index.max()
        idx_min = df.loc[df[c].notna() == True].index.min()
        nr_days = df.loc[df[c].notna() == True].shape[0]
        tpl = (c,idx_min,idx_max,nr_days)
        l.append(tpl)
        
    df_times = pd.DataFrame(l)
    df_times.columns = ['CurveID','start_date','end_date','notnull_days']
    df_times['delta_days'] = df_times['end_date'] - df_times['start_date']
    df_times['perc_complete'] = df_times['notnull_days'] / df.shape[0]
    lb_time = df_times.loc[df_times['perc_complete'] >= min_percentage,'start_date'].max()
    ub_time = df_times.loc[df_times['perc_complete'] >= min_percentage,'end_date'].min()
    print("Maximum Timestamp of available data point " + str(lb_time))
    print("Minimum Timestamp of not null data point cross time series " + str(ub_time))

    lst_cols = df_times.loc[df_times['perc_complete'] >= min_percentage,'CurveID'].unique()
    df_return = df[lst_cols].loc[(df.index >= lb_time) & (df.index <= ub_time)].\
        fillna(method='bfill', inplace=False)
               
    return df_return









