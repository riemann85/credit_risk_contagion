library(ggplot2)
library(dplyr)
library(broom)
library(ggpubr)
library(readxl)
library(openxlsx)
library(lubridate)
library(bnlearn)
library(Rgraphviz)
library(readxl)
library(openxlsx)
library(xts)
library(reshape)
library(dplyr)
library(tidyr)
library(zoo)
library(infotheo)
library(bnstruct)

args = commandArgs(trailingOnly=TRUE)
sector = args[1]
n_boot = as.integer(args[2])

print(paste0('Sector is ', sector))

periods_names = c('0', '1', 'm1')

# -------- function to compute averaging network ------------

av_net_general<-function (strength, threshold,nodes){
  e = empty.graph(nodes)
  significant = (strength$strength > threshold) | (strength$strength == 
                                                     1)
  if ("direction" %in% names(strength)) 
    significant = significant & (strength$direction >= 0.5)
  if (!any(significant)) 
    return(e)
  candidate.arcs = as.matrix(strength[significant, c("from", 
                                                     "to"), drop = FALSE])
  if (all(bnlearn:::which.undirected(candidate.arcs))) {
    e$arcs = candidate.arcs
  }
  else {
    e$arcs = .Call(bnlearn:::call_smart_network_averaging, arcs = candidate.arcs, 
                   nodes = nodes, weights = strength$strength[significant])
  }
  e$nodes =bnlearn::: cache.structure(nodes, arcs = e$arcs)
  if ("illegal" %in% names(attributes(strength))) 
    e$learning$illegal = attr(strength, "illegal")
  
  adj_matr=matrix(data=0,nrow=length(nodes),ncol=length(nodes))
  
  if (length(e$arcs[,1])>0){
    for (ii in c(1:length(e$arcs[,1]))){
      start_point=e$arcs[ii,1]
      end_point=e$arcs[ii,2]
      pos_row=match(start_point, nodes)
      pos_col=match(end_point, nodes)
      adj_matr[pos_row,pos_col]=1}}
  
  return(adj_matr)}

# Read discrete data file
discr_data = read.csv(paste0('../Data/discrete_status_bn/discrete_data_', sector, '_complete.csv'), row.names='Date')



# Create dynamic datasets
period=c(as.Date("2019-01-01"),as.Date("2020-10-01"),as.Date("2022-02-14"))

date_list=as.Date(rownames(discr_data))
date_list_ind=matrix(data=0,nrow=length(date_list),ncol=1)
conta=1

discr_data_new<-matrix(as.numeric(as.matrix(discr_data)),ncol=ncol(discr_data))
discr_data_new<-discr_data_new*2+1
discr_data_new<-data.frame(discr_data_new)

date_list <-sort(date_list)

# +
for(zz in 1:length(date_list)){
  
    
  if (date_list[zz] <= period[conta]){
    date_list_ind[zz]=conta 
  }else{
    conta=conta+1
    date_list_ind[zz]=conta
  }

}
# -

discr_data_new["split"]=date_list_ind
discr_data_splt <- split(discr_data_new,discr_data_new$split)


# Create dataset for dynamic BN
n_events=conta
n_var=ncol(discr_data)

discr_data_splt_df_in=discr_data_splt[[1]]
discr_data_splt_df_in$split <- NULL
discr_data_in<-matrix(as.numeric(as.matrix(discr_data_splt_df_in)),ncol=ncol(discr_data_splt_df_in))


# Fit static BN on first period
print(paste0('Fitting static BN for period ', periods_names[1]))

Sdataset_in <- BNDataset(data = discr_data_in,discreteness = rep(T,n_var), variables = colnames(discr_data), node.sizes =  rep(3,n_var))
Sdataset_in<-bnstruct:::bootstrap(Sdataset_in, num.boots = n_boot)
dbn_in<- learn.network(Sdataset_in,bootstrap=TRUE)

dbn_in_boot=.Call(bnlearn:::call_bootstrap_arc_coefficients, prob = dbn_in@wpdag/n_boot,nodes =dbn_in@variables )
adj_matr_dbn_in<-av_net_general(dbn_in_boot,0.9,dbn_in@variables)
dbn_in@dag<-adj_matr_dbn_in
dbn_in<-learn.params(dbn_in, Sdataset_in, ess = 1)

dbn_graph<-dbn_in

df_bn_0 = data.frame(dbn_in@dag, row.names = dbn_in@variables)
colnames(df_bn_0) = dbn_in@variables
write.csv2(df_bn_0, paste0('../Output/6.1_DBN_Results/dbn_fit_files/', sector, '_static_0.csv'), row.names=FALSE)

adj_matr_pvs=dag(dbn_in)
mat_pvs=as.matrix(Sdataset_in@raw.data)

# Fit dynamic bayesian networks on periods 0-1 and 1-m1
for(ii in seq(2,n_events)){

  print(paste0('Fitting dynamic BN between periods ', periods_names[ii-1], ' and ', periods_names[ii]))
    
  discr_data_splt_df=discr_data_splt[[ii]]
  discr_data_splt_df$split <- NULL
  discr_data_ii<-matrix(as.numeric(as.matrix(discr_data_splt_df)),ncol=n_var)
  new.mat <- matrix(data = discr_data_ii, ncol = n_var)
  colnames(new.mat)<- lapply(Sdataset_in@variables, paste0,paste("_",as.character(ii-1),sep=""))
  mat<-mat_pvs
  colnames(mat) <- lapply(Sdataset_in@variables, paste0,paste("_",as.character(ii-2),sep=""))
  max_rows<-max(nrow(mat),nrow(new.mat))
  if (nrow(mat)==max_rows){
    new.mat<-rbind(new.mat,matrix(data=NA,nrow(mat)-nrow(new.mat),ncol(new.mat)))
  }else{
    mat<-rbind(mat,matrix(data=NA,nrow(new.mat)-nrow(mat),ncol(mat)))
  }
  
  mat_fin <- cbind(mat, new.mat)
  Sdataset_curr <- BNDataset(data = mat_fin,
                             discreteness = rep(T, ncol(mat_fin)),
                             variables =colnames(mat_fin) ,
                             node.sizes = rep(3, ncol(mat_fin)))
  new.dag <- matrix(0, nrow=n_var*2, ncol=n_var*2)
  if (ii > 2){
      new.dag[1:n_var, 1:n_var] <- adj_matr_pvs
  }
  layers <- c(rep(1,n_var),rep(2,n_var))
  Sdataset_curr<-bnstruct:::bootstrap(Sdataset_curr, num.boots = n_boot,imputation=TRUE)
  layer_struct_m=diag(1,2,2)
  layer_struct_m[2,1]=1
  dbn_curr <- learn.dynamic.network(Sdataset_curr,
                                    initial.network = new.dag,
                                    layering = layers,
                                    bootstrap=TRUE,
                                    num.time.steps = 2,
                                    use.imputed.data = FALSE)
  dbn_curr_boot=.Call(bnlearn:::call_bootstrap_arc_coefficients, prob = dbn_curr@wpdag/n_boot,nodes =dbn_curr@variables )
  adj_matr_dbn_curr<-av_net_general(dbn_curr_boot,0.6,dbn_curr@variables)
  dbn_curr@dag<-adj_matr_dbn_curr
  dbn_curr<-learn.params(dbn_curr, Sdataset_curr, ess = 1)
  n_matr_start=n_var+1
  n_matr_end=2*n_var
  adj_matr_pvs=dag(dbn_curr)[n_matr_start:n_matr_end,n_matr_start:n_matr_end]
  mat_pvs=new.mat
  dbn_graph@dag<-adj_matr_pvs
  dbn_graph@variables<-colnames(new.mat)
    
  bn_first = data.frame(dbn_curr@dag[1:n_var, 1:n_var],
                        row.names = dbn_curr@variables[1:n_var])
  colnames(bn_first) = dbn_curr@variables[1:n_var]
  write.csv2(bn_first, paste0('../Output/6.1_DBN_Results/dbn_fit_files/', sector, '_dyn_first_', ii-2, '.csv'), row.names=FALSE)

  bn_cross = data.frame(dbn_curr@dag[1:n_var, n_matr_start:n_matr_end],
                        row.names = dbn_curr@variables[1:n_var])
  colnames(bn_cross) = dbn_curr@variables[n_matr_start:n_matr_end]
  write.csv2(bn_cross, paste0('../Output/6.1_DBN_Results/dbn_fit_files/', sector, '_dyn_cross_', ii-2, '_', ii-1, '.csv'), row.names=FALSE)

    
  bn_last = data.frame(dbn_curr@dag[n_matr_start:n_matr_end, n_matr_start:n_matr_end],
                        row.names = dbn_curr@variables[n_matr_start:n_matr_end])
  colnames(bn_last) = dbn_curr@variables[n_matr_start:n_matr_end]
  write.csv2(bn_last, paste0('../Output/6.1_DBN_Results/dbn_fit_files/', sector, '_dyn_last_', ii-1, '.csv'), row.names=FALSE)

}


