'''
This module contains functions used for time series clustering with time-window based approaches.
'''

import numpy as np
import pandas as pd
from tsmoothie.smoother import *


def split_series_in_time_windows(df, window_shape, step=None, time_series_scaler=None, smoother=None, return_smooth=False):
    '''
    This functions splits time series data in time windows of the specified length. It can also apply smoothing on data, if required.
    Time series' length is cut to the highest multiple of window_shape lower than original time series' length.
    
    Arguments:
        df: dataframe with shape (n_series, n_timestamps) with time series data
        window_shape: length of each time window
        step: the step used to generate the sliding windows. Default=None means step=window_shape, so disjoint time windows are defined
        time_series_scaler: instantiated object from tslearn.preprocessing used to scale time series data. Default=None means no scaling
        smoother: instantiated object from tsmoothie.smoother to smooth time series data. Default=None means LowessSmoother(0.6, 1)
        return_smooth: specify whether you want original data or smoothed data. Default=False, return original data
        
    Returns:
        window_values: np.array of shape (n_series * n_windows, window_shape) with time series data split in windows. Series are stack in the following order: first, there are all windows of the first series in input df, then all windows of the second series in input df, etc.
    '''   
        
    if step is None:
        step = window_shape
        
    if smoother is None:
        smoother = LowessSmoother(smooth_fraction=0.6, iterations=1)

    smoother = WindowWrapper(smoother, window_shape=window_shape, step=step)

    smooth_data_df = pd.DataFrame()

    for i in df.index:
        curr_series = df.loc[i][:int(window_shape*np.floor(df.shape[1]/window_shape))]
        smoother_result = smoother.smooth(curr_series)
        if return_smooth:
            smooth_data_df = pd.concat([smooth_data_df, pd.DataFrame(smoother_result.Smoother.smooth_data)])
        else:
            smooth_data_df = pd.concat([smooth_data_df, pd.DataFrame(smoother_result.Smoother.data)])


    if time_series_scaler is not None:
        window_values = np.squeeze(time_series_scaler.fit_transform(smooth_data_df))
    else:
        window_values = np.squeeze(smooth_data_df.values)
        
    return window_values



def get_time_windows_bounds(df, window_shape):
    '''
    This function allows to identify time windows' start and end dates.
    
    Arguments:
        df: dataframe with shape (n_series, n_timestamps) with time series data, where column names are dates
        window_shape: length of each time window
        
    Returns:
        time_windows: dictionary with time window id as key (0, ..., n_window-1) and 2-elements list with first and last day of time window as datetime.date objects. If columns of input df are strings (rather than datetime.date object), the elements of each list will be strings as well.
        string_time_windows: dictionary with time window id as key and string with time series range as value
    '''
    
    
    # Define first and last day of each time window

    dates = df.loc[df.index[0]][:int(window_shape*np.floor(df.shape[1]/window_shape))].index
    time_windows = {}
    for i in range(int(np.floor(df.shape[1]/window_shape))):
        time_windows[i] = dates[[i*window_shape, (i+1)*window_shape-1]]
        
    string_time_windows = {}
    if type(time_windows[0][0]) != str:
        for i in time_windows:
            string_time_windows[i] = time_windows[i][0].strftime('%d/%m/%Y') + '-' + time_windows[i][1].strftime('%d/%m/%Y')
    else:
        for i in time_windows:
            string_time_windows[i] = time_windows[i][0].replace('-', '/') + '-' + time_windows[i][1].replace('-', '/')
    
    return time_windows, string_time_windows
    
    

