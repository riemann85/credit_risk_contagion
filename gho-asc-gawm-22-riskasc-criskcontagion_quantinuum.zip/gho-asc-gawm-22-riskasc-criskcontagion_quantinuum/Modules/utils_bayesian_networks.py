'''
This module contains utilities for data preparation for Bayesian Network fitting.
'''

import pandas as pd
import numpy as np
import sys
sys.path.append('Modules')
from read_prepare_input_clustering import *
from datetime import timedelta


def define_discrete_states_based_on_volatility_jumps(df, roll_window, final_dates, output_path, type_name):
    '''
    This function creates the datasets with the discrete states determined by jumps in issuers' volatitlies for the specified sector in each of the periods specified by the input dates and in the whole time horizon available in the data.
    
    Arguments:
        df: df with shape (n_timesteps, n_curves) with dates as index, containing observations for all curves
        roll_window: int specifying the number of days of the rolling window for computation of standard deviation
        final_dates: list of strings, specifying the final date of the first period and the final date of the second period
        output_path: path to the folder where the files with discrete data must be saved (expressed relative to the output of os.getcwd())
        type_name: name to be used for saving output files. Default=''
        
    Returns:
        The function does not return any value, it saves the .csv files with the discrete states for each period and in the whole time horizon at the specified path.
    '''
    
    first_date = min(df.index)
    last_date = max(df.index)
    first_date = (first_date - timedelta(days=1)).strftime('%Y-%m-%d')
    last_date = last_date.strftime('%Y-%m-%d')

    for i in range(len(final_dates)+1):

        # Define min and max date of the current period
        if i == 0:
            min_date = first_date
        else:
            min_date = final_dates[i-1]

        if i==len(final_dates):
            max_date = last_date
        else:
            max_date = final_dates[i]

        all_rf_pivot0_full = df.\
            loc[lambda x: (x.index > min_date) & (x.index  <= max_date)]
        
        # Compute rolling standard deviation
        N_or0 = all_rf_pivot0_full.shape[0]
        N_rf0 = all_rf_pivot0_full.shape[1]
        all_rf_pivot0_full_stdev = all_rf_pivot0_full.rolling(roll_window).std().fillna(0)
        all_rf_pivot0_full_stdev = all_rf_pivot0_full_stdev.tail(N_or0-roll_window+1)
        all_rf_pivot0_full = all_rf_pivot0_full.tail(N_or0-roll_window+1)
        
        # Determine jumps
        N0 = all_rf_pivot0_full.shape[0]
        all_rf_pivot0_full_pvs = all_rf_pivot0_full.head(N0-2).reset_index(drop=True)
        all_rf_pivot0_full_mid = all_rf_pivot0_full.head(N0-1).tail(N0-2).reset_index(drop=True)
        all_rf_pivot0_full_nxt = all_rf_pivot0_full.tail(N0-2).reset_index(drop=True)
        upw_jumps0=1*((all_rf_pivot0_full_mid<all_rf_pivot0_full_pvs) & \
                      (all_rf_pivot0_full_mid<all_rf_pivot0_full_nxt) & \
                      (all_rf_pivot0_full_nxt-all_rf_pivot0_full_mid > \
                       all_rf_pivot0_full_stdev.head(N0-1).tail(N0-2).reset_index(drop=True)))
        
        # Add lag dependence: if x_i(t)=0 and exists a j t.c x_j(t)=1 and x_i(t+1)=1 or x_i(t+2)=1 or x_i(t+3)=1 --> x_i(t)=0.5
        N_uj0 = upw_jumps0.shape[0]
        upw_jump0_nxt_1 = pd.concat([upw_jumps0.tail(N_uj0-1),
                                     pd.DataFrame(np.zeros((1, N_rf0)), columns=upw_jumps0.columns, dtype=int)]).reset_index(drop=True)
        upw_jump0_nxt_2 = pd.concat([upw_jumps0.tail(N_uj0-2),
                                     pd.DataFrame(np.zeros((2, N_rf0)), columns=upw_jumps0.columns, dtype=int)]).reset_index(drop=True)
        upw_jump0_nxt_3 = pd.concat([upw_jumps0.tail(N_uj0-3),
                                     pd.DataFrame(np.zeros((3, N_rf0)), columns=upw_jumps0.columns, dtype=int)]).reset_index(drop=True)
        exst_jump0 = pd.concat([pd.DataFrame(upw_jumps0.apply(np.any, axis=1), dtype=int)] * N_rf0, axis=1, ignore_index=True)
        exst_jump0.columns = upw_jumps0.columns
        upw_jumps_lag0 = 0.5 * (upw_jumps0==0) * (upw_jump0_nxt_1 + upw_jump0_nxt_2 + upw_jump0_nxt_3 > 0) * exst_jump0

        # Final dataset with discrete states
        discr_data0 = upw_jumps0 + upw_jumps_lag0
        
        print('Min date: ' + min_date)
        print('Max date: ' + max_date)
        print('\n')
        
        # Save results as .csv
        discr_data0.to_csv(output_path + 'discrete_data_' + type_name + '_' + min_date + '_' + max_date + '.csv', index=False)


    # Compute rolling standard deviation in the whole time horizon
    N_or= df.shape[0]
    N_rf = df.shape[1]
    all_risk_factors_stdev = df.rolling(roll_window).std().fillna(0)
    all_risk_factors_stdev = all_risk_factors_stdev.tail(N_or-roll_window+1)
    df = df.tail(N_or-roll_window+1)

    # Determine jumps in the whole time horizon
    N = df.shape[0]
    all_risk_factors_pvs = df.head(N-2).reset_index(drop=True)
    all_risk_factors_mid = df.head(N-1).tail(N-2).reset_index(drop=True)
    all_risk_factors_nxt = df.tail(N-2).reset_index(drop=True)
    upw_jumps=1*((all_risk_factors_mid<all_risk_factors_pvs) & \
                  (all_risk_factors_mid<all_risk_factors_nxt) & \
                  (all_risk_factors_nxt-all_risk_factors_mid > \
                   all_risk_factors_stdev.head(N-1).tail(N-2).reset_index(drop=True)))

    N_uj = upw_jumps.shape[0]
    upw_jump_nxt_1 = pd.concat([upw_jumps.tail(N_uj-1),
                                 pd.DataFrame(np.zeros((1, N_rf)), columns=upw_jumps.columns, dtype=int)]).reset_index(drop=True)
    upw_jump_nxt_2 = pd.concat([upw_jumps.tail(N_uj-2),
                                 pd.DataFrame(np.zeros((2, N_rf)), columns=upw_jumps.columns, dtype=int)]).reset_index(drop=True)
    upw_jump_nxt_3 = pd.concat([upw_jumps.tail(N_uj-3),
                                 pd.DataFrame(np.zeros((3, N_rf)), columns=upw_jumps.columns, dtype=int)]).reset_index(drop=True)
    exst_jump = pd.concat([pd.DataFrame(upw_jumps.apply(np.any, axis=1), dtype=int)] * N_rf, axis=1, ignore_index=True)
    exst_jump.columns = upw_jumps.columns
    upw_jumps_lag = 0.5 * (upw_jumps==0) * (upw_jump_nxt_1 + upw_jump_nxt_2 + upw_jump_nxt_3 > 0) * exst_jump


    # Final dataset with discrete states
    discr_data_complete = upw_jumps + upw_jumps_lag


    # Save results as .csv
    discr_data_complete.\
        set_index(df.index[1:(len(df)-1)]).\
        to_csv(output_path + 'discrete_data_' + type_name + '_complete.csv', index=True)

