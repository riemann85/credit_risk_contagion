'''
This module contains utilities related to different types of clustering algorithm.
'''

import numpy as np
import pandas as pd
from tslearn.clustering import TimeSeriesKMeans
from sklearn.cluster import KMeans, AgglomerativeClustering
from tslearn.clustering import silhouette_score
from sklearn.metrics import silhouette_samples
from matplotlib import pyplot as plt
import matplotlib.cm as cm
from scipy.cluster.hierarchy import fcluster, ward, dendrogram



def try_k_means_varying_k(df, use_ts_kmeans=False, metric_distance='euclidean', min_num_clusters=3, max_num_clusters=50, n_init=5,
                          max_iter=50):
    '''
    This function runs K-Means clustering on input data with different values of number of clusters and returns clustering results, silhouette and inertia of the all the clustering tests.
    
    Arguments:
        df: input df with shape (n_series, n_dim)
        use_ts_kmeans: specify whether using TimeSeriesKmeans from tslearn (True) or KMeans from sklearn (False). Default=False
        metric_distance: if use_ts_kmeans=True, distance metric to be used in the clustering algorithm. Default='euclidean'
        min_num_clusters: minimum number of clusters for the experiments. Default=3
        max_num_clusters: maximum number of clusters fot the experiments. Default=50
        n_init: number of different centroid inizialization in KMeans algorithm. Default=5
        max_iter: max number of iterations of the clustering algorithm. Default=5
        
    Returns:
        km_results: dictionary with the assigned label per each number of clusters
        silhoutte_scores: dictionary with silhouette score per each number of clusters
        inertia_info: dictionary with inertia per each number of cluster
    '''    
        
    inertias_info = {}
    silhouette_scores = {}
    km_result = {}
    
    for k in np.arange(min_num_clusters, max_num_clusters + 1, 1):
        
        if not use_ts_kmeans:
            km_fit = KMeans(n_clusters=k, max_iter=max_iter, random_state=0, n_init=n_init).fit(df)
        else:
            km_fit = TimeSeriesKMeans(n_clusters=k, metric=metric_distance, max_iter=max_iter, random_state=0, n_init=n_init,
                                      max_iter_barycenter=10).fit(df)
        km_labels = km_fit.labels_
        sil_score = silhouette_score(df, km_labels, metric=metric_distance)
        inertias_info[k] = km_fit.inertia_
        silhouette_scores[k] = sil_score
        km_result[k] = km_labels
        
    return km_result, silhouette_scores, inertias_info





def silhouette_plot(X, cluster_labels, metric_for_siluette='euclidean'):
    '''
    This function builds silhouette plot for the given data and cluster labels.
    
    Arguments:
        X: input data matrix with shape (n_samples, n_features)
        cluster_labels: array with cluster labels assigned to samples in X
        metric_for_silhouette: metric to be used for silhouette score computation. Default='euclidean'
        
    Returns:
        No return value, chart is shown.
    '''

    n_clusters = len(set(cluster_labels))
    print('Number of clusters for silhouette plot: ' + str(n_clusters))
    
    distinct_labels = np.sort(list(set(cluster_labels)))
    
    # Compute the silhouette scores for each sample
    sample_silhouette_values = silhouette_samples(X, cluster_labels)
    
    # Create a subplot with 1 row and 2 columns
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    fig.set_size_inches(18, 7)

    # The 1st subplot is the silhouette plot
    ax1.set_xlim([min(sample_silhouette_values), 1])
    # The (n_clusters+1)*10 is for inserting blank space between silhouette
    # plots of individual clusters, to demarcate them clearly.
    ax1.set_ylim([0, len(X) + (n_clusters + 1) * 10])
    
    silhouette_avg = silhouette_score(X, cluster_labels, metric=metric_for_siluette)
    print(
        "For n_clusters =",
        n_clusters,
        "The average silhouette_score is :",
        silhouette_avg,
    )
    
    y_lower = 10
    for i in range(n_clusters):
        # Aggregate the silhouette scores for samples belonging to
        # cluster i, and sort them
        curr_label = distinct_labels[i]
        ith_cluster_silhouette_values = sample_silhouette_values[cluster_labels == curr_label]

        ith_cluster_silhouette_values.sort()

        size_cluster_i = ith_cluster_silhouette_values.shape[0]
        y_upper = y_lower + size_cluster_i

        color = cm.nipy_spectral(float(i) / n_clusters)
        ax1.fill_betweenx(
            np.arange(y_lower, y_upper),
            0,
            ith_cluster_silhouette_values,
            facecolor=color,
            edgecolor=color,
            alpha=0.7,
        )

        # Label the silhouette plots with their cluster numbers at the middle
        ax1.text(-0.05, y_lower + 0.5 * size_cluster_i, str(curr_label))

        # Compute the new y_lower for next plot
        y_lower = y_upper + 10  # 10 for the 0 samples

    ax1.set_title("The silhouette plot for the various clusters.")
    ax1.set_xlabel("The silhouette coefficient values")
    ax1.set_ylabel("Cluster label")

    # The vertical line for average silhouette score of all the values
    ax1.axvline(x=silhouette_avg, color="red", linestyle="--")

    ax1.set_yticks([])  # Clear the yaxis labels / ticks
    ax1.set_xticks([-0.1, 0, 0.2, 0.4, 0.6, 0.8, 1])


def plot_kpi_by_num_clusters(kpi_info, kpi_name):
    '''
    This function builds plot with values of input kpi for clustering results with different numbers of clusters.
    
    Arguments:
        kpi_info: dictionary with number of cluster as key and value of kpi as values
        kpi_name: name of the kpi included in the kpi_info
    
    Returns:
        No return value, chart is shown.
    '''
    
    fig = plt.figure()
    k_min = min(kpi_info.keys())
    k_max = max(kpi_info.keys())

    ax1 = fig.add_subplot(111)
    ax1.plot(range(k_min, k_max + 1), kpi_info.values(), '-*')
    plt.xlabel('Number of clusters')
    plt.ylabel(kpi_name)
    plt.xticks(range(k_min, k_max + 1))
    plt.grid()

    fig.tight_layout()
    fig.set_size_inches(18.5,10.5)

    plt.show()

    

def hierarchical_clustering_and_dendrogram(df, linkage_hierarchical_clustering='ward',
                                          num_clusters=2, distance_linkage_threshold=None,
                                          linkage_metric='euclidean'):
    '''
    This function fit Hierarchical Clustering on input dataframe, plots dendrogram and returns fitted clustering object.
    
    Arguments:
        df: input df with shape (n_samples, n_dim). If linkage_metric='precomputed', shape must be (n_samples, n_samples)
        linkage_hierarchical_clustering: type of linkage to be used in Hierarchical Clustering. Default='ward'
        num_clusters: number of clusters to form as well as the number of centroids to generate. Default=2
        distance_linkage_threshold: linkage distance threshold above which, clusters will not be merged. Default=None
        linkage_metric: metric used to compute the linkage. can be “euclidean”, “l1”, “l2”, “manhattan”, “cosine”, or “precomputed”. If linkage is “ward”, only “euclidean” is accepted. If “precomputed”, input df must have shape (n_samples, n_samples) and contain distances between samples
        
    Returns:
        clf: AgglomerativeClustering object fitted on input data
        Z: linkage matrix
    '''
    
    clf = AgglomerativeClustering(n_clusters=num_clusters, distance_threshold=distance_linkage_threshold,
                                  linkage=linkage_hierarchical_clustering, compute_distances=True, compute_full_tree=True,
                                  affinity=linkage_metric)
    clf.fit_predict(df)
    
    plt.figure(figsize = (18,10))
    plt.title('Hierarchical Clustering Dendrogram')
    Z = plot_dendrogram(clf, p=10, color_threshold = 110)
    plt.show()
    
    return clf, Z


def plot_dendrogram(model, **kwargs):
    # Create linkage matrix and then plot the dendrogram
    '''
    This function plots dendrogram from fitted AgglomerativeClustering model.
    
    Arguments:
        model: fitted AgglomerativeClustering object
        **kwargs: arguments for function dendrogram in module scipy.cluster.hierarchy 
        
    Returns:
        linkage_matrix: linkage matrix representing the defined dendrogram
    '''
        
    # create the counts of samples under each node
    counts = np.zeros(model.children_.shape[0])
    n_samples = len(model.labels_)
    for i, merge in enumerate(model.children_):
        current_count = 0
        for child_idx in merge:
            if child_idx < n_samples:
                current_count += 1  # leaf node
            else:
                current_count += counts[child_idx - n_samples]
        counts[i] = current_count

    linkage_matrix = np.column_stack([model.children_, model.distances_,
                                      counts]).astype(float)

    # Plot the corresponding dendrogram
    dendrogram(linkage_matrix, **kwargs)
    return linkage_matrix    


def compute_inertia(df, clustering_results):
    '''
    This function computes inertia for a given clustering assignment of observations in the input df.
    Inertia is defined as the average squared distance of observations from their closest cluster center.
    
    Arguments:
        df: input df with shape (n_samples, n_features)
        clustering_results: array with cluster labels per each sample
        
    Returns:
        inertia:  value of inertia for the given clustering assignment
    '''
    
    temp = df.assign(cluster_label=clustering_results)
    barycenters = temp.groupby('cluster_label').mean()
    temp['dist_from_bar'] = temp.apply(lambda x: np.sum((x - barycenters.loc[x['cluster_label']])**2), axis=1)
    inertia = np.mean(temp['dist_from_bar'])
    
    return inertia

    

    





        
