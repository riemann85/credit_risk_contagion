# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Getting Started
1. **Clone repository**:
    
    1.1. Open terminal on your machine and move to the path where you want to clone the repository.

    1.2. Run *git clone https://Analytics-Solution-Centre@dev.azure.com/Analytics-Solution-Centre/GAWM-22-Risk-ASC/_git/gho-asc-gawm-22-riskasc-criskcontagion*. You might be asked for Git credentials, which can be   generated from the Azure Repository web interface by clicking "Clone" and then "Generate Git Credentials" on the right side of the screen.


2. **Create conda environment**:

    2.1. Open terminal on your machine and move to the root directory of the project repository.

    2.2. Run *conda env create -f environment.yml*.

    2.3. When the previous process ends, activate the just created environment, running *conda activate cloned_env*.

    2.4. Run the command *python -m ipykernel install --user --name=envDisplayName* to make the enviroment available in a Jupyter kernel. *envDisplayName* is the name that you will see in the list of available kernels in Jupyter Notebooks.


3. **Use a notebook**:

    3.1. Open a notebook you want to execute.

    3.2. In the tab Kernel of the Juptyter Notebook interface, select the kernel called *envDisplayName* created at step 2.4.

    3.3. Run the notebook.

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)